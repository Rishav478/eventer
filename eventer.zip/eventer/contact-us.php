<?php
include('includes/header.php');
?>

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row text-center">
					<div style="width: 100%;">
						<h2>Have Some Issue</h2>
						<h4>Feel Free To Contact Us</h4>
						<h6>VIA</h6>
						<h4><i class="fa fa-envelope"> </i> <a href="mailto:navjot.s.ota456@gmail.com">navjot.s.ota456@gmail.com</a></h4>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

<?php
include('includes/footer.php');
?>