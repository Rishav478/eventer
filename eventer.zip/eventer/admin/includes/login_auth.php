<?php

if (isset($_POST['type']) && $_POST['type'] == 'ajax') {
	
	if ((time()-$_SESSION['LAST_ACTIVE_LOGIN'])>900) {
		echo "logout";
	}

} else {

	if (isset($_SESSION['LAST_ACTIVE_LOGIN'])) {
	
		if ((time()-$_SESSION['LAST_ACTIVE_LOGIN'])>900) {
			echo "<script>window.location.href='logout.php'</script>";
		}

	}

}

?>