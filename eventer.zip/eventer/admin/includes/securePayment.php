<?php

define('appId', '177459375a2dc129084f2d1df54771');
define('secretKey', 'ab482bedc37effcee63448e1bd6e63afde84667d');
define('returnUrl', 'http://localhost/eventer/seller/thankyou.php');
define('returnUrlSubs', 'http://localhost/eventer/seller/subsThankyou.php');
define('orderIds', 'ORDS-PROM-'.date('mdY').'-'.rand(0000,999999));
define('orderIdsSub', 'ORDS-SUBS-'.date('mdY').'-'.rand(0000,999999));

?>