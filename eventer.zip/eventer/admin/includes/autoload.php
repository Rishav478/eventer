<?php

include('database.php');
include('header.php');
include('navbar.php');

?>